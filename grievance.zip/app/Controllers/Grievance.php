<?php

namespace App\Controllers;

use App\Models\Attachment;
use App\Models\Grievance as ModelsGrievance;

class Grievance extends BaseController
{

    public function index()
    {
        return view('grievance');
    }

    public function save()
    {

        $session = \Config\Services::session();
        $validation = \Config\Services::validation();

        // Define validation rules for your fields
        $validation->setRules([
            'applicant_name' => 'required',
            'mobile' => 'required',
            'district' => 'required',
            'tehsil' => 'required',
            'gram_panchayat' => 'required',
            'village' => 'required',
            'slot' => 'required',
            'department' => 'required',
            'detailed_grievance' => 'required',
            'file' => 'uploaded[file]|max_size[file,1024]|ext_in[file,pdf,jpg,jpeg,png]',
        ]);


        if ($validation->withRequest($this->request)->run()) {
            $postData = $this->request->getPost();

            $file = $this->request->getFile('file');
            $newName = $file->getRandomName();

            if ($file->isValid() && $file->move(ROOTPATH . 'public/uploads', $newName)) {

                unset($postData['file']);

                $ticket_no = strtotime(date("Y-m-d H:i:s"));

                $postData['tracking_no'] = $ticket_no;
                $postData['created_date'] = date("Y-m-d H:i:s");

                $model = new ModelsGrievance();

                $request_id = $model->insert($postData);

                if ($request_id) {

                    $attachmentModel = new Attachment();

                    $attachmentData = array(
                        'request_id' => $request_id,
                        'file_name' => $newName,
                        'created_date' => date("Y-m-d H:i:s")
                    );

                    if ($attachmentModel->insert($attachmentData)) {

                        $data = array(
                            'success_message' => $ticket_no
                        );

                        return view('thankyou', ['data' => $data]);

                    } else {

                        $session->setFlashdata('error', 'Something went wrong, please try again.');

                        return redirect()->to(base_url() . 'grievance');
                    }
                } else {
                    $session->setFlashdata('error', 'Something went wrong, please try again.');

                    return redirect()->to(base_url() . 'grievance');
                }
            } else {
                $session->setFlashdata('error', 'Something went wrong, please try again.');

                return redirect()->to(base_url() . 'grievance');
            }


            // return redirect()->to('success_page');
        } else {
            // Validation failed, return to the form with errors
            return view('grievance', ['validation' => $validation]);
        }
    }

    public function application_status()
    {

        $model = new ModelsGrievance();

        $data = $model->getAllDataDesc();

        return view('report', ['data' => $data]);
    }


    public function thankyou(){
        return view('thankyou');
    }
}
