<?php require_once('UI/header.php'); ?>


<div class="toast position-fixed end-0 bottom-0 " role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header">
        <strong class="me-auto">Success</strong>
        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body">
    <?= session("message") ?> or <?php echo session("message"); ?>
    </div>
</div>

<div class="full-container">
    <?php require_once('UI/tabs.php'); ?>


    <div class="form-container">

        <?= form_open('grievance', ['id' => 'form', 'enctype' => 'multipart/form-data']) ?>

        <div class="container">
            <div class="row">
                <div class="mb-3 col-md-3">Applicant Name</div>
                <div class="mb-3 col-md-9">
                    <input class="form-control" placeholder="Applicant Name" value="<?php echo set_value('applicant_name'); ?>" name="applicant_name" id="applicantName" type="text">
                    <?php if (isset($validation) && $validation->hasError('applicant_name')) : ?>
                        <p class="text-danger"><?php echo $validation->getError('applicant_name'); ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-3">Enter Mobile Number</div>
                <div class="mb-3 col-md-9">
                    <input class="form-control" maxlength="10" placeholder="Enter Mobile Number" value="<?php echo set_value('mobile'); ?>" name="mobile" type="text">
                    <?php if (isset($validation) && $validation->hasError('mobile')) : ?>
                        <p class="text-danger"><?php echo $validation->getError('mobile'); ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-3">District</div>
                <div class="mb-3 col-md-4">
                    <select class="form-control" value="<?php echo set_value('district'); ?>" name="district">
                        <option value="">Select District</option>
                        <option value="District-1">District-1</option>
                        <option value="District-2">District-2</option>
                        <option value="District-3">District-3</option>
                    </select>

                    <?php if (isset($validation) && $validation->hasError('district')) : ?>
                        <p class="text-danger"><?php echo $validation->getError('district'); ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-2">Tehsil</div>
                <div class="mb-3 col-md-3">

                    <select class="form-control" value="<?php echo set_value('tehsil'); ?>" name="tehsil">
                        <option value="">Select Tehsil</option>
                        <option value="Tehsil-1">Tehsil-1</option>
                        <option value="Tehsil-2">Tehsil-2</option>
                        <option value="Tehsil-3">Tehsil-3</option>
                    </select>

                    <?php if (isset($validation) && $validation->hasError('tehsil')) : ?>
                        <p class="text-danger"><?php echo $validation->getError('tehsil'); ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-3">Gram Panchayat</div>
                <div class="mb-3 col-md-4">

                    <select class="form-control" value="<?php echo set_value('gram_panchayat'); ?>" name="gram_panchayat">
                        <option value="">Select Panchayat</option>
                        <option value="Panchayat-1">Panchayat-1</option>
                        <option value="Panchayat-2">Panchayat-2</option>
                        <option value="Panchayat-3">Panchayat-3</option>
                    </select>


                    <?php if (isset($validation) && $validation->hasError('gram_panchayat')) : ?>
                        <p class="text-danger"><?php echo $validation->getError('gram_panchayat'); ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-2">Village</div>
                <div class="mb-3 col-md-3">

                    <select class="form-control" value="<?php echo set_value('village'); ?>" name="village">
                        <option value="">Select Village</option>
                        <option value="Village-1">Village-1</option>
                        <option value="Village-2">Village-2</option>
                        <option value="Village-3">Village-3</option>
                    </select>

                    <?php if (isset($validation) && $validation->hasError('village')) : ?>
                        <p class="text-danger"><?php echo $validation->getError('village'); ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-3">Select Slot for Jansunwai</div>
                <div class="mb-3 col-md-9">
                    <input class="form-control" placeholder="" value="<?php echo set_value('slot'); ?>" name="slot" type="date" min="<?php echo date('Y-m-d'); ?>">
                    <?php if (isset($validation) && $validation->hasError('slot')) : ?>
                        <p class="text-danger"><?php echo $validation->getError('slot'); ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-3">Department</div>
                <div class="mb-3 col-md-9">

                    <select class="form-control" value="<?php echo set_value('department'); ?>" name="department">
                        <option value="">Select Department</option>
                        <option value="Department-1">Department-1</option>
                        <option value="Department-2">Department-2</option>
                        <option value="Department-3">Department-3</option>
                    </select>

                    <?php if (isset($validation) && $validation->hasError('department')) : ?>
                        <p class="text-danger"><?php echo $validation->getError('department'); ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-3">Detail Grievance</div>
                <div class="mb-3 col-md-9">

                    <textarea class="form-control" name="detailed_grievance" placeholder="Detail Grievance"><?php echo set_value('detailed_grievance'); ?></textarea>

                    <?php if (isset($validation) && $validation->hasError('detailed_grievance')) : ?>
                        <p class="text-danger"><?php echo $validation->getError('detailed_grievance'); ?></p>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-3">Attach File</div>
                <div class="mb-3 col-md-6">
                    <input class="form-control" name="file" type="file" accept=".pdf, .jpg, .jpeg, .png">
                    <small class="text-muted">Accepted formats: PDF, JPG, JPEG, PNG</small>

                    <?php if (isset($validation) && $validation->hasError('file')) : ?>
                        <p class="text-danger"><?php echo $validation->getError('file'); ?></p>
                    <?php endif; ?>

                </div>
                <div class="mb-3 col-md-3"><button id="submitBtn" class="btn btn-info">Submit Request</button></div>

            </div>
        </div>

        <?= form_close() ?>

    </div>

</div>

<?php require_once('UI/footer.php'); ?>