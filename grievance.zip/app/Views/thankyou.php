<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Thank You Page</title>

    <style>
        body,
        h1,
        p {
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f0f0f0;
        }

        .thank-you {
            text-align: center;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            min-width: 500px;
            padding-bottom: 40px;
        }

        .thank-you h1 {
            font-size: 36px;
            color: #333;
        }

        .thank-you p {
            font-size: 18px;
            color: #555;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="thank-you">
            <div>
                <img src="https://pngimg.com/d/thank_you_PNG1.png" style="max-width: 200px;" />
            </div>
            <p>Your Ticket No is - <?= isset($data) ? $data['success_message'] : 'NA'; ?></p>

            <div style="margin-top: 20px;"><a href="<?php echo base_url() ?>grievance" style="background-color: #000; color: #fff; padding: 10px 15px; text-decoration: none;">Go back to home</a></div>
        </div>
    </div>
</body>

</html>