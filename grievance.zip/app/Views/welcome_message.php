<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to Grievance Portal!</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico">

    <!-- STYLES -->

</head>
<body>

<!-- HEADER: MENU + HEROE SECTION -->
<header>

    

    <div style="text-align: center;">

        <h1>Welcome to Grievance Portal!</h1>

        <h2><a href="<?php echo base_url() ?>grievance">Click Here</a> to register your complaint</h2>

    </div>

</header>

<!-- CONTENT -->


</body>
</html>