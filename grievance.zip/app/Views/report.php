<?php require_once('UI/header.php'); ?>

<div class="full-container">

    <?php require_once('UI/tabs.php'); ?>

    <div class="form-container">

        <div class="table-responsive">
            <table class="table border table-hover">
                <thead class="thead-dark">
                    <tr class="table-primary">
                        <th scope="col">Order Ticket Number</th>
                        <th scope="col">Applicant Name</th>
                        <th scope="col">Applicant Mobile Number</th>
                        <th scope="col">Date of Request</th>
                        <th scope="col">Request Slot</th>
                        <th scope="col">Support from department</th>
                        <th scope="col">Status</th>
                        <th scope="col">Document</th>
                    </tr>
                </thead>
                <tbody>

                    <?php foreach ($data as $key => $value) { ?>
                        <tr style="vertical-align:middle;">
                            <th scope="row"><?= $value['tracking_no'] ?></th>
                            <td><?= $value['applicant_name'] ?></td>
                            <td><?= $value['mobile'] ?></td>
                            <td><?= date('d/m/Y', strtotime($value['created_date'])) ?></td>
                            <td><?= date('d/m/Y', strtotime($value['slot'])) ?></td>
                            <td><?= $value['department'] ?></td>
                            <td><?= $value['application_status'] == 0 ? '<span class="text-warning">Pending</span>' : ($value['application_status'] == 1 ? '<span class="text-success">Completed</span>' : '<span class="text-danger">Rejected</span>'); ?></td>
                            <td><button type="button" class="btn btn-info" onclick="showImage('<?php echo $value['file_name'] ?>')">🗎</button></td>
                        </tr>
                    <?php } ?>

                </tbody>
            </table>
        </div>

    </div>

</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Document</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <img class="img-fluid doc" id="document" style="display: none;" />
                <iframe id="pdfDoc" class="doc" style="display: none;" width="100%" height="400px"></iframe>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php require_once('UI/footer.php'); ?>

<script>
    const showImage = (fileName) => {

        const ext = fileName.split(".");

        $('.doc').hide();

        if (ext[1] === 'pdf' || ext[1] === 'PDF') {
            var imageElement = $("#pdfDoc");
        } else {
            var imageElement = $("#document");
        }

        imageElement.attr("src", "<?php echo base_url() ?>uploads/" + fileName);
        imageElement.css('display', 'block');
        $('#exampleModal').modal("show");

       
    }

   
</script>