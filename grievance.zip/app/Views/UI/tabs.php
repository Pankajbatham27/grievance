<div class="tab-container">
    <?php
    $controllerName = service('router')->controllerName();
    $methodName = service('router')->methodName();
    ?>
    <ul>
        <li class="<?php echo ($controllerName == '\App\Controllers\Grievance' &&  ($methodName == 'index' || $methodName == 'save')) ? 'active' : '' ?>"><a href="<?php echo base_url('grievance') ?>">Raise Request</a>
        <li class="<?php echo ($controllerName == '\App\Controllers\Grievance' &&  ($methodName == 'application_status')) ? 'active' : '' ?>"><a href="<?php echo base_url('grievance/application-status') ?>">Request Status</a>
    </ul>

</div>