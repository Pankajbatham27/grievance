<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script src="<?= base_url('js/script.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>



<?php $session = \Config\Services::session();

if ($session->getFlashdata('success')) {
    $color = 'success';
    $message = $session->getFlashdata('success');
} else {
    $color = 'danger';
    $message = $session->getFlashdata('error');
}

?>


<div class="toast position-fixed end-0 top-0 bg-white">
    <div class="toast-header text-white bg-<?= $color ? $color : '' ?>">
        <strong class="me-auto">Alert</strong>
        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body">
        <?php echo $message; ?>
    </div>
</div>

<?php if ($session->getFlashdata('success') || $session->getFlashdata('error')) { ?>
    <script>
        var toastElement = $(".toast:last");
        var toastInstance = new bootstrap.Toast(toastElement);
        toastInstance.show();
    </script>
<?php } ?>



</body>

</html>