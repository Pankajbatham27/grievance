<?php

namespace App\Models;

use CodeIgniter\Model;

class Grievance extends Model
{
    protected $table = 'grievance_request';
    protected $primaryKey = 'id';
    protected $allowedFields = ['applicant_name', 'mobile', 'district', 'tehsil', 'gram_panchayat', 'village', 'slot', 'tracking_no', 'department', 'detailed_grievance', 'created_date'];


    public function getAllDataDesc()
    {
        return $this->orderBy('created_date', 'DESC')
        ->join('attachments', 'grievance_request.id = attachments.request_id', 'left')
        ->select('grievance_request.*, attachments.file_name')
        ->findAll();        
    }
}
