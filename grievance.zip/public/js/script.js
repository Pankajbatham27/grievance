$(document).ready(function () {

    $.validator.addMethod("mobileNumber", function (value, element) {
        // Remove any non-digit characters
        var cleanValue = value.replace(/\D/g, '');
        return cleanValue.length === 10 && !isNaN(cleanValue);
    }, "Please enter a valid 10-digit mobile number.");

    $("#form").validate({
        rules: {

            applicant_name: {
                required: true,
            },
            mobile: {
                required: true,
                digits: true,
                mobileNumber: true
            },
            district: {
                required: true,
            },
            tehsil: {
                required: true,
            },
            gram_panchayat: {
                required: true,
            },
            village: {
                required: true,
            },
            slot: {
                required: true,
                date: true,
                min: function () {
                    return new Date().toISOString().split("T")[0];
                }
            },
            department: {
                required: true,
            },
            detailed_grievance: {
                required: true,
            },
            file: {
                required: true,
            }
        },

        submitHandler: function (form) {
            form.submit();
        },
    });
});